PE�NA WERSJA GRY "POLANIE"
-------------------------------

OPIS:
Plik, w kt�rego wszed�e� posiadanie to nic innego jak pe�na wersja pierwszej cz�ci gry Polanie.

SPOS�B INSTALACJI:
W oryginalnej wersji gra Polanie mie�ci�a si� na sze�ciu dyskietkach i aby zainstalowa� j� na swoim komputerze, trzeba by�o wk�ada� po kolei ka�d� dyskietk�. Normalnie niemo�liwym by�o zainstalowanie gry z dysku innego ni� "A:". Dlatego te� stworzy�em prosty plik, kt�rego uruchomienie sprawi, �e gra zainstaluje si� dysku twardego. Jedynym warunkiem jest to, aby zawarto�� pliku "polanie.zip" rozpakowa� do katalogu o nazwie "POLANIE" na dysku "C:".

Po zako�czeniu instalacji nie zapomnij o ustawieniu karty d�wi�kowej w programie "Setup.exe".

Przy rozpoczynaniu nowej gry zostaniemy poproszeni o podanie pierwszego lub ostatniego s�owa znajduj�cego si� na okre�lonej stronie instrukcji. Wykaz tych s��w znajduje si� poni�ej.

-------------------------------------------------- 
| Numer strony | Pierwsze s�owo | Ostatnie s�owo | 
-------------------------------------------------- 
|      01      | Historia       | odpowiedzi     | 
|      02      | Historia       | bia�og�owami   | 
|      03      | Gdy            | uprowadzone    | 
|      04      | Musi           | operacyjnego   | 
|      05      | Instalacja     | umo�liwia      | 
|      06      | w��czenie      | pozycjami      | 
|      07      | Nowa           | prac�          | 
|      08      | G��wny         | miejscu        | 
|      09      | Okienko        | gr�            | 
|      10      | Zapisanie      | mapa           | 
|      11      | Poszczeg�lne   | jak            | 
|      12      | odtwarzanie    | opcji          | 
|      13      | Szybko��       | mo�liwe        | 
|      14      | Grupowanie     | ikon           | 
|      15      | Ikona          | szacunkiem     | 
|      16      | Sterowanie     | prac�          | 
|      17      | Budynki        | rytua�y        | 
|      18      | To             | fragmentem     | 
|      19      | Palisada       | indziej        | 
|      20      | Porady         | wojownik�w     | 
|      21      | Pytania        | problem        | 
|      22      | Gra            | instrukcji     | 
-------------------------------------------------- 

Je�eli mimo wszystko b�dziesz mia� jeszcze jakie� w�tpliwo�ci lub czego� nie rozumiesz, napisz. Ch�tnie pomog�!


-------------------------------
DOKUMENTACJ� OPRACOWA�:
Janusz "Swoosh" Prokulewicz
jprokulewicz@poczta.onet.pl
www.polanie.prv.pl